<?php

$connection = mysqli_connect('localhost', 'root', '', 'iv_site');
$connect = new PDO("mysql:host=localhost; dbname=iv_site", "root", "");

//$connection = mysqli_connect('sdb-g.hosting.stackcp.net', 'access_db-313835ed62', 'k1l2985wc7', 'access_db-313835ed62');
//$connect = new PDO("mysql:host=sdb-g.hosting.stackcp.net; dbname=access_db-313835ed62", "access_db-313835ed62", "k1l2985wc7");
?>