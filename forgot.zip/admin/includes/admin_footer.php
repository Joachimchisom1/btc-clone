</div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/luckmoshyJqueryPagnation.js"></script>
    <script src="js/team.js"></script>
      <!----pagenation links--->
    <script src="js/script.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
